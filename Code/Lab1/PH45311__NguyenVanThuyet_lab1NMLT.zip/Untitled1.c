//Khai bao thu vien stdio.h
#include<stdio.h>
int main(){
	/*Trinh bay chuoi:Nguyen Van Thuyet*/
	printf("Nguyen Van Thuyet");
	return 0;
	}
