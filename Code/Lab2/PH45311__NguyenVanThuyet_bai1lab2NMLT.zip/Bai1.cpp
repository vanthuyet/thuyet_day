#include<stdio.h>
int main(){
	//Nhap hai so tu ban phim
	float a,b;
	printf("Nhap vao gia tr cua a =");
	scanf("%f",&a);
	printf("Nhap vao gia tri cua b =");
	scanf("%f",&b);
	float tong = a+b, hieu= a-b;
	printf("tong la:%.f\n",tong);
	printf("hieu la:%.f\n",hieu);
	return 0;
	}
	
