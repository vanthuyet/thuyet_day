#include<stdio.h>
int main(){
//bai 2
	int CHIEUDAI,CHIEURONG,chuvi,dientich;
	printf("Nhap vao CHIEUDAI =");
	scanf("%d",&CHIEUDAI);
	printf("Nhap vao CHIEURONG =");
	scanf("%d",&CHIEURONG);
	chuvi=(CHIEUDAI+CHIEURONG)*2;
	dientich=CHIEUDAI*CHIEURONG;
	printf("Chu vi hcn la:%d\n",chuvi);
	printf("Dien tich hcn la:%d",dientich);
	return 0;
	}
